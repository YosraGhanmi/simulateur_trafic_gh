# Simulateur de Trafic Routier 

Un simulateur de trafic routier en Python permettant de modéliser des routes, des véhicules et des réseaux de circulation.

## Installation

```bash
pip install simulateur_trafic_gh
